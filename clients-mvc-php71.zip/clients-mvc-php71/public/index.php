
<?php
use App\Core\Database;
use App\Repositories\ClientRepository;
use App\Controllers\ClientController;

error_reporting(E_ALL);
ini_set('display_errors', 1);

define('BASE_PATH', realpath(__DIR__ . '/..'));
require BASE_PATH . '/app/Core/Autoloader.php';
$config = require BASE_PATH . '/app/Config/config.php';

App\Core\Database::init($config);

$repo = new ClientRepository();
$controller = new ClientController($repo, $config['sender']);

$action = isset($_GET['action']) ? $_GET['action'] : 'index';

switch ($action) {
    case 'index':
        $controller->index();
        break;
    case 'create':
        $controller->create();
        break;
    case 'store':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Método no permitido'); }
        $controller->store();
        break;
    case 'edit':
        $controller->edit();
        break;
    case 'update':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit('Método no permitido'); }
        $controller->update();
        break;
    case 'delete':
        $controller->delete();
        break;
    case 'label':
        $controller->label();
        break;
    default:
        http_response_code(404); echo 'Ruta no encontrada';
}
