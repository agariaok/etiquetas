
<?php /** @var array $errors */ /** @var array $old */ ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?= isset($old['id']) ? 'Editar' : 'Nuevo' ?> cliente</title>
  <style>
    body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;margin:24px;background:#f7f7f7}
    .card{background:#fff;border-radius:16px;padding:20px;max-width:900px;margin:auto;box-shadow:0 10px 24px rgba(0,0,0,.08)}
    form{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
    label{font-size:.9rem;color:#333}
    input{padding:10px;border:1px solid #ddd;border-radius:10px;width:100%}
    .full{grid-column:1 / -1}
    .error{color:#b00020;font-size:.85rem}
    .actions{display:flex;gap:12px;justify-content:flex-end;margin-top:8px}
    .btn{padding:10px 14px;border:0;border-radius:10px;background:#111;color:#fff;cursor:pointer;text-decoration:none;display:inline-block}
    a.btn{background:#555}
  </style>
</head>
<body>
  <div class="card">
    <h2><?= isset($old['id']) ? 'Editar' : 'Nuevo' ?> cliente</h2>
    <form method="post" action="/index.php?action=<?= isset($old['id']) ? 'update' : 'store' ?>">
      <?php if (isset($old['id'])): ?>
        <input type="hidden" name="id" value="<?= (int)$old['id'] ?>">
      <?php endif; ?>

      <div>
        <label>Nombre
          <input name="nombre" value="<?= htmlspecialchars(isset($old['nombre'])?$old['nombre']:'') ?>" required>
        </label>
        <div class="error"><?= isset($errors['nombre'])?$errors['nombre']:'' ?></div>
      </div>
      <div>
        <label>Apellido
          <input name="apellido" value="<?= htmlspecialchars(isset($old['apellido'])?$old['apellido']:'') ?>" required>
        </label>
        <div class="error"><?= isset($errors['apellido'])?$errors['apellido']:'' ?></div>
      </div>
      <div>
        <label>DNI
          <input name="dni" value="<?= htmlspecialchars(isset($old['dni'])?$old['dni']:'') ?>" required>
        </label>
        <div class="error"><?= isset($errors['dni'])?$errors['dni']:'' ?></div>
      </div>

      <div class="full">
        <label>Domicilio
          <input name="domicilio" value="<?= htmlspecialchars(isset($old['domicilio'])?$old['domicilio']:'') ?>" required>
        </label>
        <div class="error"><?= isset($errors['domicilio'])?$errors['domicilio']:'' ?></div>
      </div>

      <div>
        <label>Provincia
          <input name="provincia" value="<?= htmlspecialchars(isset($old['provincia'])?$old['provincia']:'') ?>" required>
        </label>
        <div class="error"><?= isset($errors['provincia'])?$errors['provincia']:'' ?></div>
      </div>
      <div>
        <label>Localidad
          <input name="localidad" value="<?= htmlspecialchars(isset($old['localidad'])?$old['localidad']:'') ?>" required>
        </label>
        <div class="error"><?= isset($errors['localidad'])?$errors['localidad']:'' ?></div>
      </div>
      <div>
        <label>Código Postal
          <input name="cp" value="<?= htmlspecialchars(isset($old['cp'])?$old['cp']:'') ?>" required>
        </label>
        <div class="error"><?= isset($errors['cp'])?$errors['cp']:'' ?></div>
      </div>
      <div>
        <label>Teléfono
          <input name="telefono" value="<?= htmlspecialchars(isset($old['telefono'])?$old['telefono']:'') ?>" required>
        </label>
        <div class="error"><?= isset($errors['telefono'])?$errors['telefono']:'' ?></div>
      </div>
      <div>
        <label>Email
          <input name="email" type="email" value="<?= htmlspecialchars(isset($old['email'])?$old['email']:'') ?>" required>
        </label>
        <div class="error"><?= isset($errors['email'])?$errors['email']:'' ?></div>
      </div>
      <div>
        <label>Transporte
          <input name="transporte" value="<?= htmlspecialchars(isset($old['transporte'])?$old['transporte']:'') ?>" required>
        </label>
        <div class="error"><?= isset($errors['transporte'])?$errors['transporte']:'' ?></div>
      </div>
      <div>
        <label>Peso (kg)
          <input name="peso" placeholder="2.50" value="<?= htmlspecialchars(isset($old['peso'])?$old['peso']:'') ?>">
        </label>
        <div class="error"><?= isset($errors['peso'])?$errors['peso']:'' ?></div>
      </div>
      <div>
        <label>Bulto (cantidad)
          <input name="bulto" value="<?= htmlspecialchars(isset($old['bulto'])?$old['bulto']:'1') ?>" required>
        </label>
        <div class="error"><?= isset($errors['bulto'])?$errors['bulto']:'' ?></div>
      </div>

      <div class="full actions">
        <a class="btn" href="/index.php?action=index">Volver</a>
        <button class="btn" type="submit">Guardar</button>
      </div>
    </form>
  </div>
</body>
</html>
