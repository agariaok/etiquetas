
<?php /** @var App\Models\Client $client */ /** @var array $sender */ ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Etiqueta #<?= (int)$client->id ?></title>
  <style>
    @media print { .no-print{ display:none } }
    body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;margin:24px;background:#f5f5f5}
    .sheet{width:108mm; height:148mm; background:#fff; margin:auto; padding:12mm; box-shadow:0 8px 24px rgba(0,0,0,.1); border-radius:8px}
    h1{font-size:16px;margin:0 0 6px}
    .blk{border:1px solid #111;border-radius:8px;padding:8px;margin-bottom:10px}
    .row{display:flex;justify-content:space-between;gap:8px}
    .row > div{flex:1}
    .badge{display:inline-block;padding:3px 8px;border-radius:6px;border:1px solid #111;font-weight:600}
    .muted{color:#555}
    .actions{margin:12px 0}
  </style>
</head>
<body>
  <div class="sheet">
    <div class="actions no-print">
      <button onclick="window.print()">🖨️ Imprimir</button>
      <a href="/index.php?action=index">Volver</a>
    </div>
    <h1>Etiqueta de Envío #<?= (int)$client->id ?></h1>

    <div class="blk">
      <div class="badge">REMITENTE</div>
      <div><strong><?= htmlspecialchars($sender['nombre'] . ' ' . $sender['apellido']) ?></strong></div>
      <div>DNI: <?= htmlspecialchars($sender['dni']) ?></div>
      <div>Localidad: <?= htmlspecialchars($sender['localidad']) ?></div>
      <div>CP: <?= htmlspecialchars($sender['cp']) ?></div>
      <div>Tel: <?= htmlspecialchars($sender['telefono']) ?></div>
      <div>Email: <?= htmlspecialchars($sender['email']) ?></div>
    </div>

    <div class="blk">
      <div class="badge">DESTINATARIO</div>
      <div><strong><?= htmlspecialchars($client->nombre . ' ' . $client->apellido) ?></strong></div>
      <div>DNI: <?= htmlspecialchars($client->dni) ?></div>
      <div>Domicilio: <?= htmlspecialchars($client->domicilio) ?></div>
      <div><?= htmlspecialchars($client->localidad) ?>, <?= htmlspecialchars($client->provincia) ?> (CP <?= htmlspecialchars($client->cp) ?>)</div>
      <div>Tel: <?= htmlspecialchars($client->telefono) ?> | Email: <?= htmlspecialchars($client->email) ?></div>
    </div>

    <div class="blk">
      <div class="row">
        <div>Transporte: <strong><?= htmlspecialchars($client->transporte) ?></strong></div>
        <div>Peso: <strong><?= htmlspecialchars($client->peso ?: '—') ?></strong> kg</div>
        <div>Bulto: <strong><?= htmlspecialchars($client->bulto) ?></strong></div>
      </div>
    </div>

    <div class="muted">Generado — <?= htmlspecialchars(date('Y-m-d H:i')) ?></div>
  </div>
</body>
</html>
