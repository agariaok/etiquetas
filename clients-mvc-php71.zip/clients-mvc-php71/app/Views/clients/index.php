
<?php /** @var array $clients */ ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Clientes</title>
  <style>
    body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;margin:24px;background:#f7f7f7}
    .card{background:#fff;border-radius:16px;padding:16px;box-shadow:0 10px 24px rgba(0,0,0,.08);max-width:1100px;margin:auto}
    table{width:100%;border-collapse:collapse;margin-top:12px}
    th,td{padding:8px 10px;border-bottom:1px solid #eee;font-size:.95rem}
    th{text-align:left}
    .actions a{margin-right:8px;text-decoration:none}
    .btn{display:inline-block;background:#111;color:#fff;padding:8px 12px;border-radius:10px;text-decoration:none}
    .muted{color:#666}
    .grid{display:grid;grid-template-columns:repeat(6,1fr);gap:8px}
    input{padding:8px;border:1px solid #ddd;border-radius:10px;width:100%}
    .topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
    .badge{display:inline-block;background:#efefef;padding:4px 8px;border-radius:10px;margin-left:8px}
  </style>
</head>
<body>
  <div class="card">
    <div class="topbar">
      <form class="grid" method="get" action="/index.php">
        <input type="hidden" name="action" value="index">
        <input name="q" placeholder="Buscar por nombre, apellido, DNI, email, localidad" value="<?= htmlspecialchars(isset($_GET['q'])?$_GET['q']:'') ?>">
        <input name="localidad" placeholder="Localidad" value="<?= htmlspecialchars(isset($_GET['localidad'])?$_GET['localidad']:'') ?>">
        <input name="cp" placeholder="CP" value="<?= htmlspecialchars(isset($_GET['cp'])?$_GET['cp']:'') ?>">
        <input name="transporte" placeholder="Transporte" value="<?= htmlspecialchars(isset($_GET['transporte'])?$_GET['transporte']:'') ?>">
        <button class="btn" type="submit">Filtrar</button>
        <a class="btn" href="/index.php?action=index">Limpiar</a>
      </form>
      <div>
        <a class="btn" href="/index.php?action=create">+ Nuevo cliente</a>
      </div>
    </div>

    <?php if (isset($_GET['saved'])): ?><div class="badge">✅ Guardado</div><?php endif; ?>
    <?php if (isset($_GET['updated'])): ?><div class="badge">✏️ Actualizado</div><?php endif; ?>
    <?php if (isset($_GET['deleted'])): ?><div class="badge">🗑️ Eliminado</div><?php endif; ?>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>DNI</th>
          <th>Localidad</th>
          <th>CP</th>
          <th>Transporte</th>
          <th class="muted">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$clients): ?>
          <tr><td colspan="7" class="muted">Sin resultados</td></tr>
        <?php else: foreach ($clients as $c): ?>
          <tr>
            <td><?= (int)$c->id ?></td>
            <td><?= htmlspecialchars($c->nombre . ' ' . $c->apellido) ?></td>
            <td><?= htmlspecialchars($c->dni) ?></td>
            <td><?= htmlspecialchars($c->localidad) ?></td>
            <td><?= htmlspecialchars($c->cp) ?></td>
            <td><?= htmlspecialchars($c->transporte) ?></td>
            <td class="actions">
              <a href="/index.php?action=edit&id=<?= (int)$c->id ?>">Editar</a>
              <a href="/index.php?action=delete&id=<?= (int)$c->id ?>" onclick="return confirm('¿Eliminar este registro?')">Eliminar</a>
              <a href="/index.php?action=label&id=<?= (int)$c->id ?>">Etiqueta</a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</body>
</html>
