
<?php
namespace App\Repositories;

use App\Models\Client;
use App\Core\Database;
use PDO;

class ClientRepository
{
    public function create(Client $c)
    {
        $sql = 'INSERT INTO clients (nombre,apellido,dni,domicilio,provincia,localidad,cp,telefono,email,transporte,peso,bulto,created_at)
                VALUES (:nombre,:apellido,:dni,:domicilio,:provincia,:localidad,:cp,:telefono,:email,:transporte,:peso,:bulto,:created_at)';
        $stmt = Database::pdo()->prepare($sql);
        $stmt->execute([
            ':nombre' => $c->nombre,
            ':apellido' => $c->apellido,
            ':dni' => $c->dni,
            ':domicilio' => $c->domicilio,
            ':provincia' => $c->provincia,
            ':localidad' => $c->localidad,
            ':cp' => $c->cp,
            ':telefono' => $c->telefono,
            ':email' => $c->email,
            ':transporte' => $c->transporte,
            ':peso' => $c->peso,
            ':bulto' => $c->bulto,
            ':created_at' => $c->created_at,
        ]);
        return (int)Database::pdo()->lastInsertId();
    }

    public function update(Client $c)
    {
        $sql = 'UPDATE clients SET nombre=:nombre,apellido=:apellido,dni=:dni,domicilio=:domicilio,provincia=:provincia,localidad=:localidad,cp=:cp,telefono=:telefono,email=:email,transporte=:transporte,peso=:peso,bulto=:bulto WHERE id=:id';
        $stmt = Database::pdo()->prepare($sql);
        return $stmt->execute([
            ':id' => (int)$c->id,
            ':nombre' => $c->nombre,
            ':apellido' => $c->apellido,
            ':dni' => $c->dni,
            ':domicilio' => $c->domicilio,
            ':provincia' => $c->provincia,
            ':localidad' => $c->localidad,
            ':cp' => $c->cp,
            ':telefono' => $c->telefono,
            ':email' => $c->email,
            ':transporte' => $c->transporte,
            ':peso' => $c->peso,
            ':bulto' => $c->bulto,
        ]);
    }

    public function delete($id)
    {
        $stmt = Database::pdo()->prepare('DELETE FROM clients WHERE id = :id');
        return $stmt->execute([':id' => (int)$id]);
    }

    public function findById($id)
    {
        $stmt = Database::pdo()->prepare('SELECT * FROM clients WHERE id = :id');
        $stmt->execute([':id' => (int)$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? new Client($row) : null;
    }

    public function search(array $filters = [])
    {
        $sql = 'SELECT * FROM clients WHERE 1=1';
        $params = [];

        if (!empty($filters['q'])) {
            $sql .= ' AND (nombre LIKE :q OR apellido LIKE :q OR dni LIKE :q OR email LIKE :q OR localidad LIKE :q)';
            $params[':q'] = '%'.$filters['q'].'%';
        }
        if (!empty($filters['transporte'])) {
            $sql .= ' AND transporte LIKE :transporte';
            $params[':transporte'] = '%'.$filters['transporte'].'%';
        }
        if (!empty($filters['cp'])) {
            $sql .= ' AND cp = :cp';
            $params[':cp'] = $filters['cp'];
        }
        if (!empty($filters['localidad'])) {
            $sql .= ' AND localidad LIKE :localidad';
            $params[':localidad'] = '%'.$filters['localidad'].'%';
        }

        $sql .= ' ORDER BY id DESC';
        $stmt = Database::pdo()->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $list = [];
        foreach ($rows as $r) $list[] = new Client($r);
        return $list;
    }
}
