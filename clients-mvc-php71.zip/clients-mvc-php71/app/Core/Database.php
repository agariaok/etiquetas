
<?php
namespace App\Core;

use PDO; use PDOException; use RuntimeException;

class Database
{
    private static $pdo = null;

    public static function init(array $config)
    {
        if (self::$pdo) return;
        $dsn  = $config['db']['dsn'];
        $user = isset($config['db']['user']) ? $config['db']['user'] : null;
        $pass = isset($config['db']['password']) ? $config['db']['password'] : null;
        try {
            self::$pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        } catch (PDOException $e) {
            throw new RuntimeException('DB connection failed: ' . $e->getMessage());
        }
    }

    public static function pdo()
    {
        if (!self::$pdo) throw new RuntimeException('Database not initialized.');
        return self::$pdo;
    }
}
