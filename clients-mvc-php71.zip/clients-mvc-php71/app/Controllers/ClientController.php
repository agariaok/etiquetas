
<?php
namespace App\Controllers;

use App\Models\Client;
use App\Repositories\ClientRepository;

class ClientController
{
    private $repo;
    private $sender;

    public function __construct(ClientRepository $repo, array $sender)
    {
        $this->repo = $repo;
        $this->sender = $sender;
    }

    public function index()
    {
        $filters = [
            'q' => isset($_GET['q']) ? trim($_GET['q']) : '',
            'transporte' => isset($_GET['transporte']) ? trim($_GET['transporte']) : '',
            'cp' => isset($_GET['cp']) ? trim($_GET['cp']) : '',
            'localidad' => isset($_GET['localidad']) ? trim($_GET['localidad']) : '',
        ];
        $clients = $this->repo->search($filters);
        require __DIR__ . '/../Views/clients/index.php';
    }

    public function create()
    {
        $errors = [];
        $old = [];
        require __DIR__ . '/../Views/clients/form.php';
    }

    public function store()
    {
        $client = new Client($_POST);
        $errors = $client->validate();
        $old = $_POST;
        if ($errors) {
            require __DIR__ . '/../Views/clients/form.php';
            return;
        }
        $id = $this->repo->create($client);
        header('Location: /index.php?action=index&saved=1');
        exit;
    }

    public function edit()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $client = $this->repo->findById($id);
        if (!$client) { http_response_code(404); echo 'Registro no encontrado'; return; }
        $errors = [];
        $old = (array)$client;
        require __DIR__ . '/../Views/clients/form.php';
    }

    public function update()
    {
        $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $orig = $this->repo->findById($id);
        if (!$orig) { http_response_code(404); echo 'Registro no encontrado'; return; }

        $data = $_POST;
        $data['id'] = $id;
        $client = new Client($data);
        $errors = $client->validate();
        $old = $data;
        if ($errors) {
            require __DIR__ . '/../Views/clients/form.php';
            return;
        }
        $this->repo->update($client);
        header('Location: /index.php?action=index&updated=1');
        exit;
    }

    public function delete()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        if ($id) $this->repo->delete($id);
        header('Location: /index.php?action=index&deleted=1');
        exit;
    }

    public function label()
    {
        $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
        $client = $this->repo->findById($id);
        if (!$client) { http_response_code(404); echo 'Registro no encontrado'; return; }
        $sender = $this->sender;
        require __DIR__ . '/../Views/clients/label.php';
    }
}
